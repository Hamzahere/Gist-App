import React from 'react'; 
import '../component-styles/TitleDesc.css'
// import { Typography } from "antd";
// const { Title } = Typography;
  
export const TitleDesc=()=>
{
  return (
    <div className="Title">
      <h1>GIST Search</h1>
            <div className="Title-Subtitle"></div>
    </div>
  )
};